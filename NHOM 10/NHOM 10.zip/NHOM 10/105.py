L=[]
print("Nhap so nguyen:")
while True:
    n=int(input())
    if n==0:
        break
print(L[::-1])
    
    